import time

from src.char.BaseChar import BaseChar, SwitchPriority


class Hiyuki(BaseChar):
    """绯雪主C: 放R变身 -> 爆发宏 -> 切人。

    爆发宏分两段:
      定时段  A3 -> 闪避 -> A3 -> 长按E升空 -> 空中居合x2(第2发后点E下落)
              -> A3 -> [处决 -> A1]  (方括号内只在真有处决提示时走)
      收尾段  闪避进架势 -> 居合x3(启动轴)/x3(循环轴) -> 预输入重击 -> 重击中按住R -> R2

    【点按 E 落地后检测"能否直接进重击连段"】: 绯雪预求身形态持有 3 格心念(300 点),
    攒满后按住攻击键会触发强化重击(武霜·居合)。点按 E 落地那一刻心念往往已经满了,
    但固定定时序列不检查这个, 仍会走 attack_chain 里的平 A, 白白打出溢出的"第 4 格",
    拖慢重击起手, 表现为"明明能量已经满 3 格, 却接着平 A 再强化 E"。

    现在: 点按 E 之后强制刷新一帧, 调 can_enter_heavy_combo() 检测 ——
      · lib_heavy_available()  (hiyuki_lib_forte 图标亮起 = 心念满 3 格)
      · in_kendo_stance()      (hiyuki_left 图标亮起 = 已进入居合架势)
    两个信号任一满足就直接 finish_with_r2(), 严格走"重击 -> R2"的最优循环;
    都不满足才走原来的 attack_chain -> 处决分支 -> finish_with_r2() 流程。
    """

    FIELD_TIME_OUT = 12.0
    INTRO_HOLD_TIMEOUT = 8.0
    STANDARD_LIB_CD_MAX = 3.5
    STANDARD_HOLD_SLICE = 1.0
    HEAVY_FORTE_TIME_OUT = 1.2

    M_A_CHAIN = 1.20
    M_A_INTERVAL = 0.15
    M_A_ONE = 0.55
    M_AFTER_DODGE = 0.35
    M_HOLD_E_RISE = 0.85
    M_HOLD_E_LAND = 0.85
    M_AFTER_RISE = 0.28
    M_AIR_KENDO_INTERVAL = 0.60
    M_KENDO_LAND = 0.55
    M_AFTER_PLUNGE = 0.90
    M_LAND_RECOVER = 0.20
    M_EXECUTE_ANIM = 1.60
    AIR_KENDO_COUNT = 2
    RISE_E_WAIT = 1.2

    # 点按 E 之后到检测重击条件之间再等一小段, 让游戏状态/画面刷新
    M_PRECHECK_SETTLE = 0.08

    M_KENDO_INTERVAL = 0.45
    M_DODGE_TO_KENDO = 0.05
    GROUND_KENDO_COUNT_FIRST = 3
    GROUND_KENDO_COUNT = 3

    KENDO1_DELAY = 0.20
    KENDO_DERIVE = 0.65
    KENDO_SPAM_INTERVAL = 0.10
    KENDO_SPAM_LAST_GAP = 0.05
    KENDO_OUT_TO_HOLD = 0.30
    HEAVY_TO_R = 0.80
    HEAVY_ANIM = 2.50
    R2_CHARGE_FIRST = 6.5
    R2_CHARGE = 2.0
    R2_HOLD_FIRST = 9.05
    R2_HOLD = 4.05

    # 连点窗口相对最后一刀出刀时刻的收尾偏移。0 表示"最后一刀出刀那一瞬就停手"。
    KENDO_SPAM_STOP_OFFSET = 0.0

    LIB2_KENDO_COUNT = 3
    HOLD_LIB_TIME_OUT = 6.0
    HOLD_LIB_CD_WAIT = 1.5
    POST_LIB2_TEAM_WAIT = 0.8
    WAIT_LOCK_TIME_OUT = 2.0

    OUTRO_HARD_LIMIT = 12.0
    OUTRO_STALL_TIME = 3.0
    CON_TOP_UP_CHAIN = 0.5
    SWITCH_TARGET_NAME = 'char_suisui'
    DIRECT_SWITCH_INDEX = 1
    LIB_ANIM_WAIT = 2.5
    LEAVE_SWITCH_TIMEOUT = 3.0

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.lib_permission = True
        self.lib2_count = 0
        self.just_transformed = False
        self.r2_used = False
        self.macro_t0 = 0.0
        self.macro_marks = []
        self.check_f_on_switch = False

    def switch_out(self, con_full=False):
        super().switch_out(con_full)
        self.lib2_count = 0
        self.just_transformed = False

    def reset_state(self):
        super().reset_state()
        self.r2_used = False
        self.check_f_on_switch = False

    def do_perform(self):
        self.click_echo(time_out=0)

        if self.has_intro or not self.liberation_available():
            self.hold_attack_until_lib(
                min_hold=self.intro_motion_freeze_duration if self.has_intro else 0.0)

        if self.has_long_action() and self.task.get_cd('liberation') <= self.STANDARD_LIB_CD_MAX:
            self.perform_standard()

        lib_ok = False
        if self.just_transformed:
            self.just_transformed = False
            lib_ok = self.transform_macro()

        if not lib_ok and self.has_long_action2():
            lib_ok = self.perform_lib()
        if not lib_ok and self.lib_permission and self.liberation_available():
            lib_ok = self.hold_liberation()

        self.leave(skip_outro=lib_ok)

    def hold_attack_until_lib(self, min_hold=0.0, timeout=None):
        timeout = self.INTRO_HOLD_TIMEOUT if timeout is None else timeout
        start = time.time()
        self.task.mouse_down()
        try:
            while self.time_elapsed_accounting_for_freeze(start) < timeout:
                if self.time_elapsed_accounting_for_freeze(start) >= min_hold \
                        and self.liberation_available():
                    return True
                self.sleep(0.1)
        finally:
            self.task.mouse_up()
        return False

    def perform_standard(self):
        while self.has_long_action() and self.field_elapsed() < self.FIELD_TIME_OUT:
            if self.liberation_available() and self.click_liberation(click_f=False):
                self.just_transformed = True
                return
            self.click_echo(time_out=0)
            self.click_resonance(send_click=False, time_out=0, click_f=False)
            self.hold_attack_until_lib(timeout=self.STANDARD_HOLD_SLICE)
            self.sleep(0.05)

    def field_elapsed(self):
        return self.time_elapsed_accounting_for_freeze(self.last_perform)

    def transform_macro(self):
        ground = self.GROUND_KENDO_COUNT_FIRST if not self.r2_used else self.GROUND_KENDO_COUNT
        self.logger.info(f'hiyuki macro: A3-dodge-A3 -> rise -> air kendo x{self.AIR_KENDO_COUNT} '
                         f'-> A3 -> [execute] -> dodge -> kendo x{ground} -> heavy -> R2')
        previous = getattr(self.task, 'skip_combat_check', False)
        self.task.skip_combat_check = True
        try:
            self.macro_start()
            self.attack_chain()
            self.macro_dodge(self.M_AFTER_DODGE)
            self.attack_chain()
            self.macro_rise()

            for i in range(self.AIR_KENDO_COUNT):
                last = i == self.AIR_KENDO_COUNT - 1
                self.macro_kendo(self.M_KENDO_LAND if last else self.M_AIR_KENDO_INTERVAL)
            self.macro_tap_e(self.M_AFTER_PLUNGE)

            # 【关键检查点】: 点按 E 落地后, 强制刷新一帧再检测是否满足直接进重击连段。
            # 如果心念已满 3 格(hiyuki_lib_forte 亮) 或已经在架势中(hiyuki_left 亮),
            # 就直接进 finish_with_r2 —— 跳过剩余的普攻连段和处决分支, 不再打出溢出的
            # 第 4 格能量, 严格按"重击 -> R2"的最优循环走。
            self.macro_wait(self.M_PRECHECK_SETTLE)
            self.task.next_frame()
            if self.can_enter_heavy_combo():
                self.logger.info('hiyuki macro: heavy combo condition met after land-E, '
                                 'skipping attack chain and going straight to heavy+R2')
                self.macro_mark('precheck_hit')
                return self.finish_with_r2()

            self.macro_mark('precheck_miss')
            self.attack_chain()
            if self.macro_execute():
                self.click()
                self.macro_mark('a_after_f')
                self.macro_wait(self.M_A_ONE)
            return self.finish_with_r2()
        finally:
            self.task.skip_combat_check = previous

    def can_enter_heavy_combo(self):
        """点按 E 落地后, 检测是否满足直接进入"强化重击 -> R2"连段的条件。

        两个独立信号, 满足任一即可:
          1. lib_heavy_available(): hiyuki_lib_forte 图标亮起 —— 绯雪预求身形态下
             心念满 3 格时出现的专用图标, 是最直接的"能量满了"判据。
          2. in_kendo_stance(): hiyuki_left 图标亮起 —— 已在居合架势中, 此时按攻击键
             同样会进入强化重击, 不必再走普攻连段。

        两个图标都不亮时才返回 False, 走原来的 attack_chain -> 处决 -> finish_with_r2
        流程, 保证不会因为漏检而卡死。

        Returns: 是否满足直接进重击连段的条件。
        """
        if self.lib_heavy_available():
            return True
        if self.in_kendo_stance():
            return True
        return False

    def attack_chain(self):
        self.continues_normal_attack(self.M_A_CHAIN, interval=self.M_A_INTERVAL)
        self.macro_mark('a3')

    def finish_with_r2(self):
        count = self.GROUND_KENDO_COUNT_FIRST if not self.r2_used else self.GROUND_KENDO_COUNT
        self.logger.info(f'hiyuki macro: ground kendo count={count} (r2_used={self.r2_used})')
        dodge_at = time.time()
        self.macro_dodge(self.M_DODGE_TO_KENDO)
        last_kendo_out = dodge_at + self.KENDO1_DELAY + (count - 1) * self.KENDO_DERIVE
        hold_at = last_kendo_out + self.KENDO_OUT_TO_HOLD
        heavy_start = last_kendo_out + self.KENDO_DERIVE

        last_click_by = last_kendo_out + self.KENDO_SPAM_STOP_OFFSET

        self.macro_mark('kendo_spam')
        clicks = 0
        while True:
            now = time.time()
            if now >= last_click_by:
                break
            self.click()
            clicks += 1
            next_click = now + self.KENDO_SPAM_INTERVAL
            if next_click >= last_click_by:
                break
            self.macro_wait(max(0.0, next_click - time.time()))
        self.macro_mark(f'kendo_end{clicks}')
        self.macro_wait(max(0.0, hold_at - time.time()))
        return self.hold_heavy_into_r2(heavy_start)

    def in_kendo_stance(self):
        return bool(self.task.find_one('hiyuki_left', threshold=0.5))

    def lib_heavy_available(self):
        return bool(self.task.find_one('hiyuki_lib_forte', threshold=0.7))

    def r2_press_time(self):
        return self.R2_HOLD if self.r2_used else self.R2_HOLD_FIRST

    def hold_heavy_into_r2(self, heavy_start):
        charge = self.R2_CHARGE if self.r2_used else self.R2_CHARGE_FIRST
        start = time.time()
        release_r = heavy_start + self.HEAVY_ANIM + charge
        self.task.mouse_down()
        self.macro_mark('heavy')
        try:
            self.macro_wait(max(0.0, heavy_start + self.HEAVY_TO_R - time.time()))
        finally:
            self.task.mouse_up()

        key = self.get_liberation_key()
        r_down_at = time.time()
        self.task.send_key_down(key)
        self.macro_mark('R_down')
        self.logger.info(f'hiyuki macro timeline: {self.macro_timeline()}')
        try:
            self.macro_wait(max(0.0, release_r - time.time()))
        finally:
            self.task.send_key_up(key)
        press_time = time.time() - r_down_at

        self.r2_used = True
        self.record_liberation_use()
        self.task.in_liberation = True
        self.task.wait_until(lambda: self.task.in_team()[0], time_out=self.POST_LIB2_TEAM_WAIT)
        self.task.in_liberation = False
        self.add_freeze_duration(start, time.time() - start)
        self.lib2_count = 0
        self.logger.info(f'hiyuki macro: R2 released (held {press_time:.1f}s)')
        return True

    def macro_wait(self, sec):
        end = time.time() + sec
        while True:
            left = end - time.time()
            if left <= 0:
                return
            time.sleep(min(0.1, left))
            self.task.executor.check_enabled(check_pause=False)

    def macro_start(self):
        self.macro_t0 = time.time()
        self.macro_marks = []

    def macro_mark(self, name):
        self.macro_marks.append(f'{name}@{time.time() - self.macro_t0:.2f}')

    def macro_timeline(self):
        return ' '.join(self.macro_marks)

    def macro_rise(self):
        cd = self.task.get_cd('resonance')
        if cd > 0 and self.RISE_E_WAIT > 0:
            self.logger.warning(f'hiyuki macro: resonance on cd {cd:.1f}s at rise, waiting')
            self.task.wait_until(lambda: self.task.get_cd('resonance') <= 0,
                                 post_action=self.click, time_out=self.RISE_E_WAIT)
        self.macro_hold_e(self.M_HOLD_E_RISE, self.M_AFTER_RISE)

    def macro_dodge(self, settle):
        self.task.click(key='right')
        self.macro_mark('dodge')
        self.macro_wait(settle)

    def macro_hold_e(self, hold, settle):
        self.task.send_key_down(self.get_resonance_key())
        self.macro_mark('E_down')
        try:
            self.macro_wait(hold)
        finally:
            self.task.send_key_up(self.get_resonance_key())
        self.record_resonance_use()
        self.macro_mark('E_up')
        self.macro_wait(settle)

    def macro_tap_e(self, settle):
        self.task.send_key(self.get_resonance_key())
        self.record_resonance_use()
        self.macro_mark('E_tap')
        self.macro_wait(settle)

    def macro_kendo(self, settle=None):
        self.click()
        self.macro_mark('kendo')
        self.macro_wait(self.M_KENDO_INTERVAL if settle is None else settle)

    def macro_execute(self):
        if not self.execute_available():
            return False
        start = time.time()
        self.task.send_key('f')
        self.macro_mark('F')
        self.task.can_break = False
        self.task.wait_until(lambda: not self.execute_prompt(), time_out=0.8)
        self.macro_wait(self.M_EXECUTE_ANIM)
        self.add_freeze_duration(start, time.time() - start)
        return True

    def execute_available(self):
        self.task.next_frame()
        prompt = bool(self.execute_prompt())
        if prompt and not self.task.is_pick_f():
            return True
        bar_full = bool(self.task.find_one('f_break_full', threshold=0.92))
        self.logger.info(f'hiyuki macro: skip F (f_break={prompt} bar_full={bar_full})')
        return False

    def execute_prompt(self):
        box = self.task.box_of_screen(0.2, 0.2, 0.75, 0.8, hcenter=True, vcenter=True)
        return bool(self.task.find_one('f_break', box=box, target_height=720))

    def perform_lib(self):
        """宏没走通时的兜底: 反应式循环。检查能量满优先于 E, 避免误按普通 E。"""
        timeout = self.FIELD_TIME_OUT
        while self.has_long_action2() and self.field_elapsed() < timeout:
            self.click_echo(time_out=0)
            lib_heavy_avail = self.lib_heavy_available()
            is_timeout = self.field_elapsed() >= timeout - 0.5

            if self.lib_permission and self.liberation_available() and (
                    self.lib2_count >= self.LIB2_KENDO_COUNT or is_timeout):
                if self.hold_liberation():
                    self.lib2_count = 0
                    return True

            if lib_heavy_avail:
                if is_timeout:
                    break
                if self.wait_locked(self.WAIT_LOCK_TIME_OUT):
                    self.heavy_forte_fast(self.lib_heavy_available)
                if self.task.wait_until(self.liberation_available, post_action=self.click,
                                        time_out=0.5):
                    if self.wait_locked(self.WAIT_LOCK_TIME_OUT) and self.hold_liberation():
                        self.lib2_count = 0
                        return True
                self.lib2_count += 1
                self.sleep(0.1)
                continue

            res = self.click_resonance(send_click=False, time_out=0, click_f=False)
            if res and res[0]:
                if is_timeout:
                    break
                self.macro_hold_e(self.M_HOLD_E_LAND, self.M_LAND_RECOVER)
            elif self.in_kendo_stance():
                self.task.wait_until(lambda: not self.in_kendo_stance(),
                                     post_action=self.click, time_out=3.0)
                if is_timeout:
                    break
                self.sleep(0.1)
            elif bool(self.task.find_one('hiyuki_right', threshold=0.5)):
                self.task.click(key='right', interval=1.0)
                self.sleep(0.1)
            else:
                self.click()
            self.sleep(0.05)

        if self.lib_permission and self.liberation_available() and self.hold_liberation():
            self.lib2_count = 0
            return True
        return False

    def hold_liberation(self):
        if not self.task.use_liberation:
            return False

        sent = False
        start = time.time()
        while self.task.in_team()[0] and time.time() - start < self.HOLD_LIB_TIME_OUT:
            if self.liberation_available():
                self.task.send_key_down(self.get_liberation_key())
                sent = True
                break
            if self.task.get_cd('liberation') > self.HOLD_LIB_CD_WAIT:
                break
            self.sleep(0.05, check_combat=False)

        if not sent:
            return False

        self.macro_wait(self.r2_press_time())
        self.r2_used = True

        self.task.in_liberation = True
        self.task.send_key_up(self.get_liberation_key())
        self.task.wait_until(lambda: self.task.in_team()[0], time_out=self.POST_LIB2_TEAM_WAIT)
        self.task.in_liberation = False
        self.record_liberation_use()
        self.add_freeze_duration(start, time.time() - start)
        self.logger.info(f'hold_liberation end {time.time() - start:.1f}s')
        return True

    def leave(self, skip_outro=False):
        previous = getattr(self.task, 'skip_combat_check', False)
        self.task.skip_combat_check = True
        try:
            if skip_outro and self.direct_switch(assume_intro=True):
                return
            if not skip_outro:
                self.ensure_outro()
            self.switch_next_char()
        except Exception as e:
            self.logger.warning(f'hiyuki leave failed ({e}), trying direct switch')
            if not self.direct_switch(assume_intro=skip_outro):
                raise
        finally:
            self.task.skip_combat_check = previous

    def ensure_outro(self):
        if self.task.wait_until(self.is_con_full, time_out=0.8):
            return True

        start = time.time()
        best_con = self.get_current_con()
        last_gain = time.time()
        while True:
            if self.is_con_full():
                return True
            if self.time_elapsed_accounting_for_freeze(start) >= self.OUTRO_HARD_LIMIT:
                self.logger.warning('hiyuki hit outro hard limit, switching without outro')
                return False
            con = self.get_current_con()
            if con > best_con + 0.01:
                best_con = con
                last_gain = time.time()
            elif time.time() - last_gain > self.OUTRO_STALL_TIME:
                self.logger.warning(f'hiyuki con stuck at {con:.2f}, switching without outro')
                return False

            if self.echo_available():
                self.click_echo(time_out=0)
                continue
            res = self.click_resonance(send_click=False, time_out=0, click_f=False)
            if res and res[0]:
                self.macro_hold_e(self.M_HOLD_E_LAND, self.M_LAND_RECOVER)
                self.macro_kendo()
                continue
            if self.is_mouse_forte_full():
                self.heavy_forte_fast(self.is_mouse_forte_full)
                continue
            self.continues_normal_attack(self.CON_TOP_UP_CHAIN, until_con_full=True)

    def direct_switch(self, assume_intro=False):
        target = self.switch_target()
        slot = self.DIRECT_SWITCH_INDEX if target is None else target.index + 1
        if slot - 1 == self.index:
            self.logger.warning(f'hiyuki direct switch: slot {slot} is myself, '
                                f'team={self.team_roster()}')
            return False
        has_intro = True if assume_intro else self.wait_con_full()

        deadline = self.LIB_ANIM_WAIT + self.LEAVE_SWITCH_TIMEOUT
        start = time.time()
        switched = False
        self.task.mouse_down()
        try:
            while time.time() - start < deadline:
                in_team, current_index, _ = self.task.in_team()
                if in_team and current_index == slot - 1:
                    self.logger.info(f'hiyuki direct switched to slot {slot} '
                                     f'(intro={has_intro}, {time.time() - start:.1f}s)')
                    switched = True
                    break
                self.task.send_key(slot)
                self.sleep(0.12, check_combat=False)
        finally:
            self.task.mouse_up()

        if not switched:
            self.logger.warning(f'hiyuki direct switch to slot {slot} failed')
            return False

        if target is None:
            self.task.load_chars()
            target = self.char_at_index(slot - 1)
        if target is None or target is self:
            self.logger.warning(f'hiyuki switched to slot {slot} but could not resolve the char, '
                                f'team={self.team_roster()}')
            return True
        self.handoff_to(target, has_intro)
        return True

    def handoff_to(self, target, has_intro):
        self.task.in_liberation = False
        self.switch_out(con_full=has_intro)
        target.is_current_char = True
        target.has_intro = has_intro
        if has_intro and hasattr(target, 'note_intro_handoff'):
            target.note_intro_handoff()
        target.last_switch_in_time = time.time()
        if has_intro:
            now = time.time()
            self.task.add_freeze_duration(now, target.intro_motion_freeze_duration, -100)
            self.last_outro_time = now

    def wait_con_full(self):
        return bool(self.task.wait_until(self.is_con_full, time_out=0.5))

    def switch_target(self):
        for char in self.task.chars:
            if char is not None and char is not self and char.char_name == self.SWITCH_TARGET_NAME:
                return char
        slot_char = self.char_at_index(self.DIRECT_SWITCH_INDEX - 1)
        if slot_char is not None:
            return slot_char
        self.logger.warning(f'hiyuki switch target unresolved '
                            f'(name={self.SWITCH_TARGET_NAME} slot={self.DIRECT_SWITCH_INDEX}), '
                            f'team={self.team_roster()}')
        return None

    def char_at_index(self, index):
        return next((c for c in self.task.chars
                     if c is not None and c is not self and c.index == index), None)

    def team_roster(self):
        return [None if c is None else (c.index, str(c.char_name)) for c in self.task.chars]

    def heavy_forte_fast(self, check_fun, time_out=None):
        time_out = self.HEAVY_FORTE_TIME_OUT if time_out is None else time_out
        if not check_fun():
            return False
        self.task.mouse_down()
        try:
            success = self.task.wait_until(lambda: not check_fun(), time_out=time_out)
        finally:
            self.task.mouse_up()
        self.sleep(0.05)
        return bool(success)

    def wait_locked(self, time_out):
        return bool(self.task.wait_until(self.has_long_action2, post_action=self.click,
                                         time_out=time_out))

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if has_intro and current_char and current_char.char_name in {'char_linnai', 'char_lucilla'}:
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)