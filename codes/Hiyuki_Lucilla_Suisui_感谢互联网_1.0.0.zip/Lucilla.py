import time

from src.char.BaseChar import BaseChar, SwitchPriority


class Lucilla(BaseChar):
    LIBERATION_ANIMATION_TIME = 3.0
    LIBERATION_HEAVY_TIME = 5.0
    HEAVY_PULSE_TIME = 0.6
    # 长按E攒一格回路能量的时长。和机器/帧率有关, 时机不稳就往上调, 上游原版是 1.4。
    # 给短了会退化成点按, 静默失败, 日志里看 'Lucilla E swallowed' 的频率。
    # 【从 0.8 提到 1.0】: 实测在部分机型上 0.8 秒会退化成点按, 长按判定没触发,
    # 直接导致罗瑟拉攒不满格数。多 0.2 秒的代价极小, 换的是攒格稳定性。
    RES_HOLD_TIME = 1.0
    # 【从 7.2 提到 12.0】: 无变奏入场时需要攒 3 格(E 冷却约 1.5~2.0s, 每格长按 1.0s),
    # 7.2 秒经常差最后半格就超时, 表现就是"穗穗转罗瑟拉, 罗瑟拉攒不满能量条"。
    # 12 秒足够 3 格 + 一发大招, 且超过了穗穗 MAIN_DPS_OUTRO_LOCKOUT(24s) 的一半, 不会无限拖。
    CHARGE_TIME_OUT = 12.0
    LIBERATION_CD_SKIP = 1.5
    ECHO_WINDOW = (0.6, 4.0)
    # 【从 4.0 提到 5.0】: 大招被打断后补协奏的窗口也拉长, 避免 has_intro 误判
    EXTRA_BUDGET = 5.0
    HOLD_FIELD_OUTRO = {'char_suisui'}
    # 【新增】如果攒格超时且没有任何变奏, 反复重试的次数。空手入场时不能只试一轮就放弃
    CHARGE_RETRY = 2

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.e_count = 0
        self.check_f_on_switch = False

    def reset_state(self):
        super().reset_state()
        self.check_f_on_switch = False

    def do_perform(self):
        if not self.perform_combat():
            self.switch_next_char()

    def perform_combat(self):
        start = time.time()
        self.task.wait_until(lambda: self.task.in_team()[0], time_out=0.2)
        if self.has_intro:
            # 入场动画期间的输入会被吞, 不是延迟执行
            self.sleep(self.intro_motion_freeze_duration, check_combat=False)
        self.task.next_frame()

        self.e_count = 0
        # 接穗穗延奏时手上已经有两格, 补一格即可; 空手入场要攒满三格。
        # 【注意】: 如果穗穗离场时协奏没满, 罗瑟拉会 has_intro=False, 需要攒 3 格,
        # 这时候 CHARGE_TIME_OUT 必须给足, 否则攒到 2 格就超时, 表现就是"攒不满"。
        target = 1 if self.has_intro else 3
        hold_field = self.has_intro and self.check_outro() in self.HOLD_FIELD_OUTRO

        attempts = 0
        while attempts < self.CHARGE_RETRY:
            attempts += 1
            self.e_count = 0
            if attempts > 1:
                self.logger.warning(f'Lucilla charge retry #{attempts}, target={target}')
            if self._charge_loop(start, target, hold_field):
                return True
            # 一轮跑完没放出大招, 看看是不是已经超时了
            if self.time_elapsed_accounting_for_freeze(start) >= self.CHARGE_TIME_OUT * 2:
                self.logger.warning('Lucilla charge retry exhausted, giving up')
                break
        return False

    def _charge_loop(self, start, target, hold_field):
        """单轮攒格 -> 放大招。Returns: 大招是否真的放出去了。"""
        while self.time_elapsed_accounting_for_freeze(start) < self.CHARGE_TIME_OUT:
            if self.e_count >= target:
                if self.perform_liberation():
                    self.switch_next_char(free_intro=self.fill_con())
                    return True
                # 大招没放出说明有一发 E 被吞了, 退一格重攒
                self.logger.warning(f'Lucilla lib failed, e_count {self.e_count} -> {self.e_count - 1}')
                self.e_count = max(0, self.e_count - 1)
            elif self.time_elapsed_accounting_for_freeze(start) >= 2 and not hold_field \
                    and not self.liberation_available() \
                    and self.task.get_cd('liberation') > self.LIBERATION_CD_SKIP:
                self.logger.info('Lucilla liberation on long cd, switch to save time')
                return True  # 大招在长CD, 直接交给框架切人, 不算失败
            self.charge_once()
        self.logger.warning(f'Lucilla charge loop timed out (e_count={self.e_count}, target={target})')
        return False

    def charge_once(self):
        """长按 E 攒一格。E 在 CD 时等一小段; 长按被吞时重试一次。"""
        if not self.resonance_available():
            self.sleep(0.15)
            return
        # 【长按被吞重试】: 0.8 秒的版本在某些机器上会退化成点按, 进了 CD 但没攒到格。
        # 现在连续尝试两次, 每次稍作间隔 —— 第二次给更长的按住时长, 确保长按判定成立。
        for attempt in range(2):
            hold_time = self.RES_HOLD_TIME if attempt == 0 else self.RES_HOLD_TIME + 0.3
            self.hold_resonance(hold_time)
            cd = self.task.get_cd('resonance')
            if cd > 0:
                self.e_count += 1
                self.logger.info(f'Lucilla E #{self.e_count}, resonance cd now {cd:.1f}s')
                self.task.next_frame()
                return
            self.logger.warning(f'Lucilla E swallowed (attempt {attempt + 1}, held {hold_time:.2f}s, '
                                f'cd still {cd:.1f}s), retrying')
            self.sleep(0.1)
        self.logger.warning('Lucilla E swallowed twice, moving on')

    def hold_resonance(self, duration):
        self.task.send_key_down(self.get_resonance_key())
        try:
            self.sleep(duration, check_combat=False)
        finally:
            self.task.send_key_up(self.get_resonance_key())
        self.record_resonance_use()

    def perform_liberation(self):
        """放大招变身并输出。返回大招是否真的放出去了。"""
        if not self.task.use_liberation:
            return False

        start = time.time()
        sent = 0
        while time.time() - start < 1.5:
            if sent and not self.liberation_available():
                break  # 图标灭了 = 变身形态已激活
            self.send_liberation_key()
            sent += 1
            self.sleep(0.15, check_combat=False)
        if self.liberation_available():
            self.logger.warning(f'Lucilla liberation icon still lit after {sent} presses, not fired')
            return False

        self.record_liberation_use()
        self.logger.info(f'Lucilla perform lib ({sent} presses)')
        self.sleep(self.LIBERATION_ANIMATION_TIME, check_combat=False)
        self.pulse_heavy_attack(self.LIBERATION_HEAVY_TIME)
        # 被打断时能量会剩, 变身一结束就作废, 所以按图标打空为准
        self.pulse_until(lambda: not self.is_mouse_forte_full(), 'forte drained')
        self.logger.info(f'Lucilla perform lib end ({time.time() - start:.1f}s)')
        return True

    def pulse_heavy_attack(self, total_time):
        """脉冲重击: 每拍重新按下, 某拍被打断下一拍自动恢复。Q 在窗口内反复发。"""
        start = time.time()
        last_echo = 0
        while time.time() - start < total_time:
            elapsed = time.time() - start
            if self.ECHO_WINDOW[0] <= elapsed <= self.ECHO_WINDOW[1] and time.time() - last_echo >= 0.3:
                self.send_echo_key()
                last_echo = time.time()
            self.heavy_pulse()

    def pulse_until(self, cond, name):
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < self.EXTRA_BUDGET:
            if cond():
                self.logger.info(f'Lucilla {name} after {time.time() - start:.1f}s')
                return True
            self.heavy_pulse()
        self.logger.warning(f'Lucilla {name} timed out')
        return False

    def heavy_pulse(self):
        self.task.mouse_down()
        try:
            self.sleep(self.HEAVY_PULSE_TIME, check_combat=False)
        finally:
            self.task.mouse_up()
        self.sleep(0.02, check_combat=False)

    def fill_con(self):
        """确认协奏满再交棒。变身刚结束时能量环读数滞后, 直接读会读成 0。

        【延奏对下一棒至关重要】: 绯雪的变奏入场直接决定她能否立刻进预求身形态。
        如果罗瑟拉这里没填满就切走, 绯雪会空手接场, 整套轴会被打乱。所以这里
        一定要坚持填到满或超时, 不能读一次 0 就放弃。
        """
        if self.task.wait_until(self.is_con_full, time_out=1.5):
            return True
        # 读数已经该稳了还没满, 说明是真的短了(被打断), 站着等没用, 得打
        self.logger.info(f'Lucilla con reads {self.get_current_con():.2f} after settle, attacking')
        if self.pulse_until(self.is_con_full, 'con filled'):
            return True
        self.logger.warning(f'Lucilla con still reads {self.get_current_con():.2f}, '
                            f'next char gets no intro')
        return False

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if has_intro and current_char and current_char.char_name in {'char_verina', 'char_shorekeeper',
                                                                    'char_suisui'}:
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)