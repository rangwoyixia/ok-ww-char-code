import time

from src.Labels import Labels
from src.char.BaseChar import BaseChar, Elements, SwitchPriority


class Suisui(BaseChar):
    """穗穗: 效应体系专辅, 本体几乎无伤害, 全部价值压在「延奏」那一下。

    濯雨时只有 15 秒(游戏侧计时, 不受动画冻结影响), 退出时芳菲信直接清零 ——
    这是整套代码最硬的约束。延奏 600 档才给下一个角色 50% 攻击, 400 档只有 12%。

    站场分两条轴, 只有开头不同, 从"等第一格回路能量满"起完全一样:
      启动轴  按住攻击键 -> 等E亮 -> 按E「醒春潮」进濯雨时 -> v
      循环轴  (主C大招后变奏入场, 变奏技能本身已把她推进濯雨时) 按住攻击键 -> v
      启动轴等E的过程中还盯着芳菲信: 它涨了就说明这次其实是带变奏进来的(记账丢了),
      当场认领那段濯雨时并跳过醒春潮 —— 否则会白攒 6 秒水云息、濯雨时的计时基准
      也跟着晚记那么多, 保底闸会一路等到芳菲信被清零
      v  等第一格满 -> 按E落地 -> 等0.95秒 -> 切主C入场, 到位立刻狂点把场子要回来
         -> 回到穗穗: Q -> [保底: 三格回路能量满才准放R] -> R -> 切下一个

    攻击键是鼠标、E/Q/数字键是键盘, 互不冲突, 所以整条轴中途一次都不松手, 只在放R前松开。
    切人期间也保持按住 —— 点击落在谁身上就由谁打出来, 主C出场那两下A就是这么来的。

    大招压到最后放: 30 秒领域几乎全部覆盖后面两个角色的输出窗口。

    【离场协奏保底 & 防卡死】: 放完 R 后协奏未必立刻满, 且 R 动画期间无法普攻回能。
    离场前会强制检查协奏能量: 未满则原地按住普攻填充。若填充超时仍不满, 则明确
    标记 has_intro=False, 并走【数字键盲发切换】这条兜底路径 —— 即使队伍识别失败
    也保证人切得走, 不会卡在原地。若上一轮 leave 卡死留下残留的 misty_start,
    下一次 do_perform 会立即识别并强制离场, 不再无谓地重新走一遍启动轴。

    【三格能量保底】: LIB_CAST_RESERVE = 2.0, FORTE3_WAIT = 7.0, 轮询 sleep = 0.05 ——
    启动轴窗口偏紧时能在剩下 7 秒里持续普攻, 确保芳菲信攒到 600(三格)。

    【大招后强制落地】: 穗穗放完大招通常会滞空缓慢下落, 那段时间无法切人, 白白
    浪费 1 秒以上。R 动画刚结束时 flying() 常常还是 False, 真正升空要等 0.2~0.3 秒 ——
    所以 fast_land() 不再依赖初始 flying() 判定, 直接普攻按住一段, 覆盖升空瞬间的
    输入窗口, 触发下落攻击。全程不用 E —— 濯雨时此时已结束, 按 E 会重新消耗
    水云息进濯雨时, 破坏下一轮由主C延奏启动的节奏。

    【协奏填充拉长】: CON_FILL_TIMEOUT 从 2.5 提到 4.0 —— 放完 R 后能量环读数
    滞后, 2.5 秒经常误判填不满就 has_intro=False 切人, 导致罗瑟拉没拿到变奏、
    开局攒不满能量条。现在给足 4 秒, 反复按住普攻直到真满。
    """

    MISTY_WINDOW = 15.0  # 濯雨时总时长, 用墙钟
    LIB_CAST_RESERVE = 2.0

    OPEN_E_WAIT_TIMEOUT = 10.0
    OPEN_POLL = 0.1
    FIRST_BAR_TIME = 2.8
    FIRST_BAR_TIME_INTRO = 2.6
    SWITCH_ANCHOR_MAX = 1.5
    E_LAND_TO_SWITCH = 0.95
    BACK_TO_R = 0.05
    POST_LIB_SETTLE = 0.10

    DPS_TOUCH_OUT_TIMEOUT = 2.0
    DPS_TOUCH_BACK_TIMEOUT = 3.0
    SWITCH_KEY_RESEND = 0.22
    SWITCH_KEY_RESEND_BACK = 0.22
    SWITCH_POLL = 0.02

    DIRECT_SWITCH_TIMEOUT = 3.0
    FORCE_SWITCH_TIMEOUT = 3.0

    FORTE3_WAIT = 7.0
    FORTE3_POLL = 0.05
    FORTE3_THRESHOLD = 0.75
    FORTE2_THRESHOLD = 0.75
    FORTE3_CONFIRM = 2
    MIN_MISTY_BEFORE_LIB = 3.0
    GAUGE_GONE_CONFIRM = 4
    GAUGE_CONFIRM = 2
    MISTY_DETECT_MIN = 1.0
    INTRO_HANDOFF_TTL = 4.0

    SWITCH_TARGET_NAME = 'char_lucilla'
    DIRECT_SWITCH_INDEX = 2
    HANDOFF_CON_WAIT = 0.4
    MAIN_DPS_OUTRO_LOCKOUT = 24.0
    OUTRO_LOCKOUT = 26.0

    # 离场协奏保底: 4 秒, 确保罗瑟拉能拿到变奏
    CON_FILL_TIMEOUT = 4.0
    CON_FILL_POLL = 0.05

    # 大招后强制落地
    FAST_LAND_TIMEOUT = 2.0
    FAST_LAND_INITIAL_HOLD = 0.5  # 第一发按住普攻的时长, 覆盖"大招结束->升空"窗口
    FAST_LAND_ATTACK_HOLD = 0.20  # 后续脉冲每次按住普攻的时长
    FAST_LAND_POLL = 0.05

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.last_outro = -1
        self.misty_start = -1
        self._forte3_hits = 0
        self.intro_pending = False
        if self.ring_index < 0:
            self.ring_index = Elements.ICE

    def reset_state(self):
        super().reset_state()
        if self.ring_index < 0:
            self.ring_index = Elements.ICE

    def do_perform(self):
        if self.flying():
            self.fast_land()

        if self.misty_start > 0 and self.misty_left() <= 0:
            self.logger.warning('suisui: stale misty_start detected (previous leave failed), '
                                'forcing leave instead of restarting the opening axis')
            self.misty_start = -1
            self.leave(assume_intro=False)
            return

        if self.has_intro or self.intro_pending or self.took_intro_handoff():
            self.clear_intro_handoff()
            self.enter_misty_state()
            return self.hold_axis(opening=False)

        self.clear_intro_handoff()
        if self.in_misty():
            self.logger.info(f'suisui resuming misty, {self.misty_left():.1f}s left')
            return self.hold_axis(opening=False, skip_first_bar=True)

        return self.hold_axis(opening=True)

    def hold_axis(self, opening=False, skip_first_bar=False):
        axis = 'opening' if opening else 'loop'
        self.logger.info(f'suisui {axis} axis: hold attack -> E(land) -> dps touch -> Q -> forte3 -> R')
        axis_start = time.time() if opening else self.switch_in_anchor()
        self.task.mouse_down()
        try:
            airborne = True
            if opening:
                if self.hold_until_e_or_misty(self.OPEN_E_WAIT_TIMEOUT) == 'misty':
                    self.adopt_running_misty(axis_start)
                    airborne = False
                else:
                    self.send_resonance_key()
                    self.enter_misty_state()
                    self.sleep(self.FIRST_BAR_TIME, check_combat=False)
            elif not skip_first_bar:
                self.sleep(max(0.0, axis_start + self.FIRST_BAR_TIME_INTRO - time.time()),
                           check_combat=False)
            if airborne:
                self.send_resonance_key()
                self.sleep(self.E_LAND_TO_SWITCH, check_combat=False)

            if self.dps_touch() == 'out' and airborne:
                self.logger.info('suisui: still airborne, re-sending E and retrying the touch')
                self.send_resonance_key()
                self.sleep(self.E_LAND_TO_SWITCH, check_combat=False)
                self.dps_touch()

            self.send_echo_key()
            self.sleep(self.BACK_TO_R, check_combat=False)
            self.wait_forte3()
        finally:
            self.task.mouse_up()

        cast = self.cast_field()
        if cast:
            self.sleep(self.POST_LIB_SETTLE, check_combat=False)
            self.fast_land()
        else:
            self.logger.warning('suisui: liberation not ready at R time, leaving without field')
        self.leave(assume_intro=False)

    def fast_land(self):
        """穗穗大招后常滞空缓慢下落, 那段时间无法切人, 白白浪费 1 秒以上。

        【核心修复】: 之前用 flying() 判定 —— R 动画刚结束时它常常还是 False,
        真正升空要等 0.2~0.3 秒。`if not self.flying(): return` 直接跳出,
        什么都没做, 表现就是"穗穗放完大招还是慢慢落下来"。而且就算 flying()
        为 True, 每次点击之间只 hold 0.12 秒, 太短, 下落攻击的输入缓存没填上。

        现在的做法: 完全不依赖初始 flying() ——
          1) 先无条件按住普攻 FAST_LAND_INITIAL_HOLD 秒, 覆盖"动画结束->升空"
             这段窗口, 输入缓存会在升空第一帧被解释为下落攻击。
          2) 然后循环检测 flying(), 每次脉冲按住普攻, 直到落地或超时。

        【为什么不用 E】: 濯雨时此时已结束, 按 E 会重新消耗水云息把她推进濯雨时,
        破坏下一轮由主C延奏启动的固定节奏, 下一轮开局会走错分支。
        """
        timeout = self.FAST_LAND_TIMEOUT
        start = time.time()
        self.logger.info('suisui: forced landing after liberation (attack pulse)')
        # 阶段 1: 无条件按住一段, 覆盖升空瞬间
        self.task.mouse_down()
        try:
            self.sleep(self.FAST_LAND_INITIAL_HOLD, check_combat=False)
        finally:
            self.task.mouse_up()
        # 阶段 2: 如果还在滞空, 用更长的脉冲继续尝试触发下落攻击
        while time.time() - start < timeout:
            if not self.flying():
                break
            self.task.mouse_down()
            try:
                self.sleep(self.FAST_LAND_ATTACK_HOLD, check_combat=False)
            finally:
                self.task.mouse_up()
            self.sleep(self.FAST_LAND_POLL, check_combat=False)
        elapsed = time.time() - start
        if self.flying():
            self.logger.warning(f'suisui: still airborne after {elapsed:.2f}s fast-land')
        else:
            self.logger.info(f'suisui: landed in {elapsed:.2f}s')

    def leave(self, assume_intro=False):
        """离场前必须确保协奏满, 否则罗瑟拉拿不到变奏, 开局攒不满能量条。"""
        if not self.is_con_full():
            self.logger.info('suisui: con not full before leave, attempting to fill')
            filled = self.fill_con()
            if not filled:
                self.logger.warning('suisui: con still not full after fill, no intro for next char')
                assume_intro = False
            else:
                assume_intro = True
        else:
            assume_intro = True

        if self.direct_switch(assume_intro=assume_intro):
            return
        self.logger.warning('suisui: direct_switch failed, forcing numeric switch')
        if self.force_switch():
            return
        self.logger.warning('suisui: force_switch also failed, falling back to switch_next_char')
        self.switch_next_char()

    def fill_con(self):
        """离场前协奏未满时的保底填充: 按住普攻, 直到协奏满或超时。

        超时拉到 4.0 秒: 刚放完大招时能量环读数滞后, 2.5 秒经常误判填不满就切人。
        只按普攻, 不动 E 键 —— 她不在濯雨时状态时按E会重新进濯雨时(更亏),
        在濯雨时状态时按E会把她弹出去, 两个方向都会搞坏下一轮的起手。
        """
        start = time.time()
        self.task.mouse_down()
        try:
            while self.time_elapsed_accounting_for_freeze(start) < self.CON_FILL_TIMEOUT:
                if self.is_con_full():
                    self.logger.info(f'suisui: con full after '
                                     f'{self.time_elapsed_accounting_for_freeze(start):.1f}s')
                    return True
                self.sleep(self.CON_FILL_POLL)
        finally:
            self.task.mouse_up()
        self.logger.warning(f'suisui: con still not full after '
                            f'{self.CON_FILL_TIMEOUT:.1f}s of filling')
        return False

    def wait_forte3(self):
        start = time.time()
        gauge_seen = False
        gauge_gone = 0
        while self.time_elapsed_accounting_for_freeze(start) < self.FORTE3_WAIT:
            if self.forte3_available():
                self.logger.info(f'suisui forte3 full after '
                                 f'{self.time_elapsed_accounting_for_freeze(start):.1f}s')
                return True
            if self.gauge_present():
                gauge_seen = True
                gauge_gone = 0
            elif gauge_seen:
                gauge_gone += 1
                if gauge_gone >= self.GAUGE_GONE_CONFIRM:
                    self.logger.warning('suisui: forte gauge wiped, misty is already over '
                                        '(misty_start was wrong), casting R now')
                    return False
            left = self.misty_left()
            if 0 < self.misty_start and left <= self.LIB_CAST_RESERVE:
                self.logger.warning(f'suisui: misty closing ({left:.1f}s left) without forte3, '
                                    f'casting R now before the gauge wipes')
                return False
            self.sleep(self.FORTE3_POLL, check_combat=False)
        self.logger.warning(f'suisui forte3 still not full after {self.FORTE3_WAIT:.1f}s, casting anyway')
        return False

    def switch_in_anchor(self):
        now = time.time()
        anchored = self.last_switch_in_time
        gap = now - anchored if anchored > 0 else -1
        if 0 <= gap <= self.SWITCH_ANCHOR_MAX:
            self.logger.info(f'suisui: anchored on switch-in, {gap:.2f}s ago')
            return anchored
        self.logger.info(f'suisui: switch-in timestamp unusable (gap {gap:.2f}s), using now')
        return now

    def e_ready(self):
        return bool(self.is_e_forte_full()) or bool(self.task.find_one(Labels.suisui_e1))

    def hold_until_e_or_misty(self, timeout):
        start = time.time()
        gauge_hits = 0
        while True:
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if elapsed >= timeout:
                break
            if self.e_ready():
                self.logger.info(f'suisui opening: e ready after {elapsed:.1f}s')
                return 'e'
            if elapsed >= self.MISTY_DETECT_MIN and self.gauge_present():
                gauge_hits += 1
                if gauge_hits >= self.GAUGE_CONFIRM:
                    self.logger.warning(f'suisui opening: forte gauge filling at {elapsed:.1f}s '
                                        f'-> already in misty, the intro handoff was lost')
                    return 'misty'
            else:
                gauge_hits = 0
            self.sleep(self.OPEN_POLL)
        self.logger.info(f'suisui opening: timed out waiting for e ({timeout:.1f}s)')
        return ''

    def gauge_present(self):
        return bool(self.task.find_one(Labels.suisui_forte2, threshold=self.FORTE2_THRESHOLD)) \
            or bool(self.task.find_one(Labels.suisui_forte3, threshold=self.FORTE3_THRESHOLD))

    def adopt_running_misty(self, started_at):
        self.misty_start = started_at
        self._forte3_hits = 0
        self.logger.info(f'suisui: adopting the misty already running, '
                         f'{self.misty_left():.1f}s left counting from switch-in')

    def enter_misty_state(self):
        self.misty_start = time.time()
        self._forte3_hits = 0

    def in_misty(self):
        return self.misty_start > 0 and self.misty_left() > self.LIB_CAST_RESERVE

    def misty_left(self):
        if self.misty_start <= 0:
            return -1
        return self.MISTY_WINDOW - (time.time() - self.misty_start)

    def dps_touch(self):
        dps = self.main_dps_teammate()
        if dps is None:
            return 'none'

        start = time.time()
        here = self.index
        if not self.switch_to_index(dps.index, timeout=self.DPS_TOUCH_OUT_TIMEOUT):
            self.logger.info('suisui: failed to switch to dps, skip')
            return 'out'
        out_done = time.time()
        if not self.switch_to_index(here, timeout=self.DPS_TOUCH_BACK_TIMEOUT,
                                    resend=self.SWITCH_KEY_RESEND_BACK):
            self.logger.warning('suisui: failed to switch back from dps, leave it to the framework')
            return 'back'
        self.logger.info(f'suisui: dps touch done in {time.time() - start:.1f}s '
                         f'(out {out_done - start:.2f}s, back {time.time() - out_done:.2f}s)')
        return 'ok'

    def switch_to_index(self, index, timeout=None, resend=None):
        timeout = self.DPS_TOUCH_OUT_TIMEOUT if timeout is None else timeout
        resend = self.SWITCH_KEY_RESEND if resend is None else resend
        start = time.time()
        last_send = 0.0
        while time.time() - start < timeout:
            in_team, current_index, _ = self.task.in_team()
            if in_team and current_index == index:
                return True
            if time.time() - last_send >= resend:
                self.task.send_key(index + 1)
                last_send = time.time()
            self.sleep(self.SWITCH_POLL, check_combat=False)
        return False

    def direct_switch(self, assume_intro=False):
        target = self.switch_target()
        slot = self.DIRECT_SWITCH_INDEX if target is None else target.index + 1
        if slot - 1 == self.index:
            for i in range(1, len(self.task.chars) + 1):
                if i - 1 != self.index:
                    slot = i
                    break
            else:
                self.logger.warning('suisui direct switch: no other slot available, '
                                    f'team={self.team_roster()}')
                return False
        has_intro = True if assume_intro else self.wait_con_full()

        if not self.switch_to_index(slot - 1, timeout=self.DIRECT_SWITCH_TIMEOUT):
            self.logger.warning(f'suisui direct switch to slot {slot} failed')
            return False

        if target is None:
            self.task.load_chars()
            target = next((c for c in self.task.chars
                           if c is not None and c is not self and c.index == slot - 1), None)
        self.logger.info(f'suisui direct switched to slot {slot} (intro={has_intro})')
        if target is not None and target is not self:
            self.handoff_to(target, has_intro)
        return True

    def force_switch(self):
        target_slot = self.DIRECT_SWITCH_INDEX
        if target_slot - 1 == self.index:
            for i in range(1, len(self.task.chars) + 1):
                if i - 1 != self.index:
                    target_slot = i
                    break
        self.logger.warning(f'suisui: force switch to slot {target_slot}')
        start = time.time()
        while time.time() - start < self.FORCE_SWITCH_TIMEOUT:
            self.task.send_key(target_slot)
            in_team, current_index, _ = self.task.in_team()
            if in_team and current_index == target_slot - 1:
                target = next((c for c in self.task.chars
                               if c is not None and c is not self
                               and c.index == target_slot - 1), None)
                if target is not None:
                    target.is_current_char = True
                    target.has_intro = False
                    target.last_switch_in_time = time.time()
                self.logger.info(f'suisui: force switch succeeded to slot {target_slot}')
                return True
            self.sleep(0.15, check_combat=False)
        self.logger.warning(f'suisui: force switch to slot {target_slot} timed out')
        return False

    def handoff_to(self, target, has_intro):
        self.task.in_liberation = False
        self.switch_out(con_full=has_intro)
        target.is_current_char = True
        target.has_intro = has_intro
        if has_intro and hasattr(target, 'note_intro_handoff'):
            target.note_intro_handoff()
        target.last_switch_in_time = time.time()
        if has_intro:
            now = time.time()
            self.task.add_freeze_duration(now, target.intro_motion_freeze_duration, -100)
            self.last_outro_time = now

    def wait_con_full(self):
        if self.task.wait_until(self.is_con_full, time_out=self.HANDOFF_CON_WAIT):
            return True
        self.logger.info('suisui: con not full before switch, next char gets no intro')
        return False

    def switch_target(self):
        for char in self.task.chars:
            if char is not None and char is not self and char.char_name == self.SWITCH_TARGET_NAME:
                return char
        index = self.DIRECT_SWITCH_INDEX - 1
        return next((c for c in self.task.chars if c is not None and c.index == index), None)

    def team_roster(self):
        return [None if c is None else (c.index, str(c.char_name)) for c in self.task.chars]

    def cast_field(self):
        if not self.liberation_available():
            return False
        if self.click_liberation(wait_if_cd_ready=0.3, click_f=False):
            self.logger.info('suisui field deployed')
            return True
        return False

    def forte3_available(self):
        if 0 < self.misty_start and (time.time() - self.misty_start) < self.MIN_MISTY_BEFORE_LIB:
            return False
        if not self.task.find_one(Labels.suisui_forte3, threshold=self.FORTE3_THRESHOLD):
            self._forte3_hits = 0
            return False
        self._forte3_hits += 1
        return self._forte3_hits >= self.FORTE3_CONFIRM

    def switch_out(self, con_full=False):
        if con_full or self.current_con == 1:
            self.last_outro = time.time()
            self.misty_start = -1
        super().switch_out(con_full=con_full)

    def note_intro_handoff(self):
        self.intro_pending = True
        self.task.suisui_intro_handoff = time.time()

    def took_intro_handoff(self):
        stamp = getattr(self.task, 'suisui_intro_handoff', 0) or 0
        return 0 < stamp and time.time() - stamp <= self.INTRO_HANDOFF_TTL

    def clear_intro_handoff(self):
        self.intro_pending = False
        self.task.suisui_intro_handoff = 0

    def on_combat_end(self, chars):
        self.misty_start = -1

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        main_dps = self.main_dps_teammate()
        lockout = self.MAIN_DPS_OUTRO_LOCKOUT if main_dps else self.OUTRO_LOCKOUT
        if self.time_elapsed_accounting_for_freeze(self.last_outro) < lockout \
                and self.has_other_candidate(current_char):
            return SwitchPriority.NO

        if main_dps is not None:
            if current_char is not None and current_char.is_main_dps and has_intro:
                return SwitchPriority.MUST
            if self.has_other_candidate(current_char):
                return SwitchPriority.NO
        return SwitchPriority.MUST

    def main_dps_teammate(self):
        return next((char for char in self.task.chars
                     if char is not None and char is not self and char.is_main_dps), None)

    def has_other_candidate(self, current_char):
        return any(char is not None and char is not self and char is not current_char
                   for char in self.task.chars)